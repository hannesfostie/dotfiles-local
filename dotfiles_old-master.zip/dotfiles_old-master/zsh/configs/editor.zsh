export VISUAL=vim
export EDITOR=$VISUAL
