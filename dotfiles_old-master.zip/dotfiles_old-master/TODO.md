# Missing stuff

from brew:

* reattach-to-user-namespace
* redis-server
* the_silver_searcher
* tig
* tmux
* vim
* chruby
* heroku
* ruby-build
* libsodium
